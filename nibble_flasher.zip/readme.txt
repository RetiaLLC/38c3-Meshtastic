here is the command

./device-install.sh -f /Users/skicka/Downloads/nibble-esp32/firmware-nibble-esp32s3-master.bin
