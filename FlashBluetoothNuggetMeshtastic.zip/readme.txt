Run this command from the same folder as the firmware you want to flash
Change the serial port for the one your Nugget is connected to:

esptool.py --chip esp32s3 --port /dev/cu.usbmodem14401 --baud 921600 --before default_reset --after hard_reset write_flash \
0x0 bootloader.bin \
0x8000 partitions.bin \
0x10000 firmware.bin
